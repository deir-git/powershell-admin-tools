﻿# ===========================================================================
#  MANUTENCAO DE PC - PowerShell Edition
#  Autor: Tecnico de TI
#  Versao: 2.0
# ===========================================================================

#Requires -RunAsAdministrator
Set-StrictMode -Version Latest
$ErrorActionPreference = "SilentlyContinue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$Host.UI.RawUI.WindowTitle = "Manutencao de PC - TI"

# ===========================================================================
# CONFIGURACAO GLOBAL
# ===========================================================================
$Global:ScriptDir  = Split-Path -Parent $MyInvocation.MyCommand.Definition
$Global:LogDir     = Join-Path $ScriptDir "Logs"
$Global:ReportDir  = Join-Path $ScriptDir "Relatorios"
$Global:Timestamp  = Get-Date -Format "dd-MM-yyyy_HH-mm-ss"
$Global:LogFile    = Join-Path $LogDir "log_$Timestamp.txt"
$Global:ReportFile = Join-Path $ReportDir "relatorio_$Timestamp.txt"
$Global:HtmlReport = Join-Path $ReportDir "relatorio_$Timestamp.html"
$Global:Acoes      = [System.Collections.Generic.List[string]]::new()

foreach ($d in @($LogDir, $ReportDir)) {
    if (-not (Test-Path $d)) { New-Item -ItemType Directory -Path $d | Out-Null }
}

# ===========================================================================
# FUNCOES VISUAIS
# ===========================================================================
function Write-Log {
    param([string]$Msg)
    $linha = "[$(Get-Date -Format 'HH:mm:ss')] $Msg"
    $linha | Out-File -FilePath $Global:LogFile -Append -Encoding UTF8
}

function Write-Header {
    Clear-Host
    $cyan   = [char]27 + "[96m"
    $dim    = [char]27 + "[90m"
    $reset  = [char]27 + "[0m"
    Write-Host ""
    Write-Host "$cyan  ###+   ###+ #####+ ###+  ##+##+   ##+########+#######+###+   ##+ ######+ #####+  ######+  $reset"
    Write-Host "$cyan  ####+ ####|##+==##+####+ ##|##|   ##|+==##+==+##+====+####+  ##|##+====+##+==##+##+===##+ $reset"
    Write-Host "$cyan  ##+####+##|#######|##+##+##|##|   ##|   ##|   #####+  ##+##+ ##|##|     #######|##|   ##| $reset"
    Write-Host "$cyan  ##|+##++##|##+==##|##|+####|##|   ##|   ##|   ##+==+  ##|+####|##|     ##+==##|##|   ##| $reset"
    Write-Host "$cyan  ##| +=+ ##|##|  ##|##| +###|+######++   ##|   #######+##| +###|+######+##|  ##|+######++ $reset"
    Write-Host "$dim   +=+     +=++=+  +=++=+  +==+ +=====+    +=+   +======++=+  +==+ +=====++=+  +=+ +=====+  $reset"
    Write-Host "$dim   ==========================================================================================  $reset"
    Write-Host ""
}

function Write-StatusBar {
    $dim    = [char]27 + "[90m"
    $gray   = [char]27 + "[37m"
    $white  = [char]27 + "[97m"
    $green  = [char]27 + "[92m"
    $yellow = [char]27 + "[93m"
    $reset  = [char]27 + "[0m"

    $pc   = $env:COMPUTERNAME
    $user = $env:USERNAME
    $dt   = Get-Date -Format "dd/MM/yyyy"
    $hr   = Get-Date -Format "HH:mm"

    Write-Host "$dim   +--------------------------------------------------------------------------------------+$reset"
    Write-Host "$dim   |$reset  $gray Computador:$reset $white$pc$reset   $gray Usuario:$reset $green$user$reset   $gray Data:$reset $white$dt$reset   $gray Hora:$reset $yellow$hr$reset"
    Write-Host "$dim   |$reset  $gray Log:$reset $dim$Global:LogFile$reset"
    Write-Host "$dim   +--------------------------------------------------------------------------------------+$reset"
    Write-Host ""
}

function Write-SectionTitle {
    param([string]$Title, [string]$Color = "Cyan")
    $esc   = [char]27
    $codes = @{ Cyan="96"; Yellow="93"; Green="92"; Blue="94"; Magenta="95"; Red="91" }
    $c     = $codes[$Color]
    $dim   = "$esc[90m"
    $col   = "$esc[$c`m"
    $reset = "$esc[0m"
    $line  = "-" * 86
    Write-Host ""
    Write-Host "$dim   $line$reset"
    Write-Host "$col   >>  $Title$reset"
    Write-Host "$dim   $line$reset"
    Write-Host ""
}

function Write-Step {
    param([int]$Num, [int]$Total, [string]$Descricao)
    $yellow = [char]27 + "[93m"
    $gray   = [char]27 + "[37m"
    $reset  = [char]27 + "[0m"
    Write-Host "$yellow   [$Num/$Total]$reset $gray $Descricao...$reset"
    Write-Log "Passo $Num/$Total - $Descricao"
}

function Write-Resultado {
    param([string]$Msg, [string]$Status = "OK")
    $green  = [char]27 + "[92m"
    $red    = [char]27 + "[91m"
    $yellow = [char]27 + "[93m"
    $reset  = [char]27 + "[0m"
    switch ($Status) {
        "OK"   { Write-Host "$green   [OK]  $Msg$reset" }
        "ERRO" { Write-Host "$red   [X]  $Msg$reset" }
        "AVISO"{ Write-Host "$yellow   [!]  $Msg$reset" }
    }
    Write-Log "[$Status] $Msg"
}

function Write-ProgressBar {
    param([string]$Label, [int]$Percent, [string]$Color = "Green")
    $esc    = [char]27
    $codes  = @{ Green="92"; Yellow="93"; Red="91"; Cyan="96"; Blue="94" }
    $c      = "$esc[$($codes[$Color])m"
    $dim    = "$esc[90m"
    $white  = "$esc[97m"
    $reset  = "$esc[0m"
    $filled = [math]::Round($Percent / 2)
    $empty  = 50 - $filled
    $bar    = ("#" * $filled) + ("#" * $empty)
    Write-Host "$white   $Label$reset $c[$bar]$reset $white$Percent pct$reset"
}

function Write-Pausar {
    $dim   = [char]27 + "[90m"
    $reset = [char]27 + "[0m"
    Write-Host ""
    Write-Host "$dim   Pressione qualquer tecla para voltar ao menu...$reset"
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}

function Write-Aviso {
    param([string]$Msg)
    $yellow = [char]27 + "[93m"
    $reset  = [char]27 + "[0m"
    Write-Host "$yellow   [!]  $Msg$reset"
    Write-Log "[AVISO] $Msg"
}

# ===========================================================================
# MENU PRINCIPAL
# ===========================================================================
function Show-Menu {
    Write-Header
    Write-StatusBar

    $dim    = [char]27 + "[90m"
    $white  = [char]27 + "[97m"
    $green  = [char]27 + "[92m"
    $cyan   = [char]27 + "[96m"
    $yellow = [char]27 + "[93m"
    $blue   = [char]27 + "[94m"
    $pink   = [char]27 + "[95m"
    $orange = [char]27 + "[33m"
    $red    = [char]27 + "[91m"
    $reset  = [char]27 + "[0m"

    Write-Host "$yellow   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host "$yellow   |$reset $green >>  REDE E CONECTIVIDADE             $yellow|  |$reset $cyan >>  DIAGNOSTICO DO SISTEMA                  $yellow|$reset"
    Write-Host "$yellow   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host "$yellow   |$reset  $white [1]$reset Reparar rede e DNS              $yellow|  |$reset  $white [5]$reset CPU, memoria e processos             $yellow|$reset"
    Write-Host "$yellow   |$reset  $white [2]$reset Teste de velocidade             $yellow|  |$reset  $white [6]$reset Verificar arquivos (SFC / DISM)      $yellow|$reset"
    Write-Host "$yellow   |$reset                                      $yellow|  |$reset  $white [7]$reset Verificar disco (CHKDSK)              $yellow|$reset"
    Write-Host "$yellow   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host ""
    Write-Host "$blue   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host "$blue   |$reset $pink >>  LIMPEZA E MANUTENCAO             $blue|  |$reset $orange >>  SEGURANCA E BACKUP                     $blue|$reset"
    Write-Host "$blue   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host "$blue   |$reset  $white [3]$reset Limpar arquivos temporarios      $blue|  |$reset  $white [9]$reset Ponto de restauracao                 $blue|$reset"
    Write-Host "$blue   |$reset  $white [4]$reset Limpar cache de navegadores      $blue|  |$reset $white [10]$reset Verificar Windows Update              $blue|$reset"
    Write-Host "$blue   |$reset  $white [8]$reset Otimizar desempenho              $blue|  |$reset $white [11]$reset Scan rapido - Windows Defender        $blue|$reset"
    Write-Host "$blue   +--------------------------------------+  +---------------------------------------------+$reset"
    Write-Host ""
    Write-Host "$dim   +==========================================================================================+$reset"
    Write-Host "$dim   |$reset  $white [12]$reset Executar TUDO + gerar relatorio        $white [13]$reset Informacoes do sistema                    $dim|$reset"
    Write-Host "$dim   |$reset  $white [14]$reset Gerar relatorio (.txt + .html)         $white [15]$reset Gestao de usuarios (Active Directory)    $dim|$reset"
    Write-Host "$dim   |$reset  $red  [0]$reset Sair                                                                                     $dim|$reset"
    Write-Host "$dim   +==========================================================================================+$reset"
    Write-Host ""
    $cyan = [char]27 + "[96m"
    Write-Host -NoNewline "$cyan   #$reset Escolha uma opcao: "
}

# ===========================================================================
# 1 - REPARAR REDE
# ===========================================================================
function Invoke-RepararRede {
    Write-SectionTitle "DIAGNOSTICO E REPARO DE REDE" "Green"
    $Global:Acoes.Add("Reparo de rede executado em $(Get-Date -Format 'HH:mm')")

    Write-Step 1 6 "Liberando endereco IP"
    ipconfig /release 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "IP liberado"

    Write-Step 2 6 "Renovando endereco IP"
    ipconfig /renew 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "IP renovado"

    Write-Step 3 6 "Limpando cache de DNS"
    ipconfig /flushdns 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "Cache DNS limpo"

    Write-Step 4 6 "Resetando catalogo Winsock"
    netsh winsock reset 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "Winsock resetado (requer reinicio para efeito total)"

    Write-Step 5 6 "Resetando pilha TCP/IP"
    netsh int ip reset 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "TCP/IP resetado"

    Write-Step 6 6 "Testando conectividade"
    Write-Host ""
    $ping = Test-Connection -ComputerName 8.8.8.8 -Count 4 -ErrorAction SilentlyContinue
    if ($ping) {
        $avg = ($ping | Measure-Object -Property ResponseTime -Average).Average
        Write-Resultado "Conexao OK - Latencia media: $([math]::Round($avg,1)) ms"
        Write-ProgressBar "Qualidade da conexao:" (100 - [math]::Min($avg, 100)) "Green"
    } else {
        Write-Resultado "Sem resposta do servidor. Verifique o cabo ou o roteador." "ERRO"
    }

    Write-Aviso "Se a rede ainda nao funcionar, reinicie o computador para o reset do Winsock fazer efeito."
    Write-Pausar
}

# ===========================================================================
# 2 - TESTE DE VELOCIDADE
# ===========================================================================
function Invoke-TesteVelocidade {
    Write-SectionTitle "TESTE DE VELOCIDADE DE INTERNET" "Cyan"
    $Global:Acoes.Add("Teste de velocidade executado em $(Get-Date -Format 'HH:mm')")

    Write-Step 1 2 "Baixando arquivo de 20 MB para medir velocidade"
    $url = "https://speed.cloudflare.com/__down?bytes=20000000"
    $tmp = Join-Path $env:TEMP "speedtest_tmp.bin"

    try {
        $sw = [System.Diagnostics.Stopwatch]::StartNew()
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing
        $sw.Stop()
        $bytes   = (Get-Item $tmp).Length
        Remove-Item $tmp -Force
        $secs    = $sw.Elapsed.TotalSeconds
        $mbps    = [math]::Round(($bytes * 8 / $secs) / 1000000, 2)
        $mbBaixados = [math]::Round($bytes / 1MB, 1)

        Write-Resultado "Download: $mbBaixados MB em $([math]::Round($secs,2))s -> $mbps Mbps"

        $qualidade = if ($mbps -ge 100) { 100 }
                     elseif ($mbps -ge 50) { 80 }
                     elseif ($mbps -ge 20) { 60 }
                     elseif ($mbps -ge 5)  { 40 }
                     else { 20 }

        $cor = if ($mbps -ge 20) { "Green" } elseif ($mbps -ge 5) { "Yellow" } else { "Red" }
        Write-ProgressBar "Velocidade $mbps Mbps:" $qualidade $cor
        Write-Log "Download: $mbps Mbps"
    } catch {
        Write-Resultado "Nao foi possivel realizar o teste. Verifique a internet." "ERRO"
    }

    Write-Step 2 2 "Medindo latencia (ping)"
    Write-Host ""
    $pings = Test-Connection -ComputerName 8.8.8.8 -Count 4 -ErrorAction SilentlyContinue
    if ($pings) {
        $pings | ForEach-Object {
            $cor = if ($_.ResponseTime -lt 50) { "Green" } elseif ($_.ResponseTime -lt 150) { "Yellow" } else { "Red" }
            $pct = [math]::Max(0, 100 - $_.ResponseTime)
            Write-ProgressBar "  Ping $([math]::Round($_.ResponseTime)) ms:" $pct $cor
        }
        $avg = ($pings | Measure-Object -Property ResponseTime -Average).Average
        Write-Resultado "Latencia media: $([math]::Round($avg,1)) ms"
    } else {
        Write-Resultado "Nao foi possivel medir latencia." "AVISO"
    }

    Write-Pausar
}

# ===========================================================================
# 3 - LIMPEZA DE TEMPORARIOS
# ===========================================================================
function Invoke-LimpezaTemp {
    Write-SectionTitle "LIMPEZA DE ARQUIVOS TEMPORARIOS" "Magenta"

    $livresAntes = (Get-PSDrive ($env:SystemDrive -replace ":","")).Free
    $Global:Acoes.Add("Limpeza de temporarios em $(Get-Date -Format 'HH:mm')")

    $pastas = @(
        @{ Path = $env:TEMP;              Nome = "Temp do usuario" },
        @{ Path = "$env:WINDIR\Temp";     Nome = "Temp do Windows" },
        @{ Path = "$env:WINDIR\Prefetch"; Nome = "Prefetch" },
        @{ Path = "$env:LOCALAPPDATA\Microsoft\Windows\INetCache"; Nome = "Cache do IE/Edge legado" }
    )

    $i = 1
    foreach ($p in $pastas) {
        Write-Step $i $pastas.Count "Limpando $($p.Nome)"
        if (Test-Path $p.Path) {
            Remove-Item "$($p.Path)\*" -Recurse -Force -ErrorAction SilentlyContinue
            Write-Resultado "$($p.Nome) limpo"
        } else {
            Write-Resultado "$($p.Nome) - pasta nao encontrada" "AVISO"
        }
        $i++
    }

    Write-Step $i ($pastas.Count + 2) "Esvaziando a Lixeira"
    Clear-RecycleBin -Force -ErrorAction SilentlyContinue
    Write-Resultado "Lixeira esvaziada"

    $livresDepois = (Get-PSDrive ($env:SystemDrive -replace ":","")).Free
    $liberadoMB   = [math]::Round(($livresDepois - $livresAntes) / 1MB, 1)
    Write-Host ""
    Write-Resultado "Espaco liberado: $liberadoMB MB"
    Write-Log "Espaco liberado: $liberadoMB MB"

    Write-Pausar
}

# ===========================================================================
# 4 - LIMPEZA DE CACHE DE NAVEGADORES
# ===========================================================================
function Invoke-LimpezaNavegadores {
    Write-SectionTitle "LIMPEZA DE CACHE DE NAVEGADORES" "Magenta"
    Write-Aviso "Feche o Chrome, Edge e Firefox antes de continuar para melhores resultados."
    Write-Host ""
    $Global:Acoes.Add("Limpeza de cache de navegadores em $(Get-Date -Format 'HH:mm')")

    function Limpar-Cache($Caminho, $Nome) {
        if (Test-Path $Caminho) {
            Remove-Item "$Caminho\*" -Recurse -Force -ErrorAction SilentlyContinue
            Write-Resultado "$Nome"
        } else {
            Write-Resultado "$Nome nao encontrado neste usuario" "AVISO"
        }
    }

    # Chrome
    Write-Host ""
    $white = [char]27 + "[97m"; $reset = [char]27 + "[0m"
    Write-Host "$white   [ Google Chrome ]$reset"
    Limpar-Cache "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Cache" "Chrome - Cache principal"
    Limpar-Cache "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\Code Cache" "Chrome - Code Cache"
    Limpar-Cache "$env:LOCALAPPDATA\Google\Chrome\User Data\Default\GPUCache" "Chrome - GPU Cache"

    # Edge
    Write-Host ""
    Write-Host "$white   [ Microsoft Edge ]$reset"
    Limpar-Cache "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Cache" "Edge - Cache principal"
    Limpar-Cache "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\Code Cache" "Edge - Code Cache"
    Limpar-Cache "$env:LOCALAPPDATA\Microsoft\Edge\User Data\Default\GPUCache" "Edge - GPU Cache"

    # Firefox
    Write-Host ""
    Write-Host "$white   [ Mozilla Firefox ]$reset"
    $ffProfiles = "$env:APPDATA\Mozilla\Firefox\Profiles"
    if (Test-Path $ffProfiles) {
        Get-ChildItem $ffProfiles -Directory | ForEach-Object {
            Limpar-Cache (Join-Path $_.FullName "cache2") "Firefox - $($_.Name)"
        }
    } else {
        Write-Resultado "Firefox nao instalado" "AVISO"
    }

    Write-Pausar
}

# ===========================================================================
# 5 - DIAGNOSTICO CPU/MEMORIA/PROCESSOS
# ===========================================================================
function Invoke-Diagnostico {
    Write-SectionTitle "DIAGNOSTICO DE CPU, MEMORIA E PROCESSOS" "Cyan"
    $Global:Acoes.Add("Diagnostico de CPU/Memoria em $(Get-Date -Format 'HH:mm')")

    $cpu = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
    $os  = Get-CimInstance Win32_OperatingSystem
    $memUsadaPct = [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize) * 100, 1)
    $memUsadaGB  = [math]::Round(($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / 1MB, 2)
    $memTotalGB  = [math]::Round($os.TotalVisibleMemorySize / 1MB, 2)

    $corCPU = if ($cpu -gt 80) { "Red" } elseif ($cpu -gt 50) { "Yellow" } else { "Green" }
    $corMem = if ($memUsadaPct -gt 85) { "Red" } elseif ($memUsadaPct -gt 65) { "Yellow" } else { "Green" }

    Write-ProgressBar "CPU em uso  ($cpu pct):" $cpu $corCPU
    Write-ProgressBar "Memoria     ($memUsadaPct pct) - $memUsadaGB GB / $memTotalGB GB:" $memUsadaPct $corMem
    Write-Host ""

    $white  = [char]27 + "[97m"; $yellow = [char]27 + "[93m"; $reset = [char]27 + "[0m"
    Write-Host "$yellow   Top 10 processos por CPU:$reset"
    Write-Host "$white   {0,-30} {1,8} {2,12}$reset" -f "Nome", "CPU (s)", "Memoria (MB)"
    Write-Host "   " + ("-" * 55)
    Get-Process | Sort-Object CPU -Descending | Select-Object -First 10 | ForEach-Object {
        $memMB = [math]::Round($_.WS / 1MB, 1)
        $cpuS  = [math]::Round($_.CPU, 1)
        $cor   = if ($cpuS -gt 100) { [char]27 + "[91m" } elseif ($cpuS -gt 30) { [char]27 + "[93m" } else { [char]27 + "[37m" }
        Write-Host "$cor   {0,-30} {1,8} {2,12}$reset" -f $_.Name, $cpuS, $memMB
    }

    Write-Host ""
    Write-Host "$yellow   Top 10 processos por Memoria:$reset"
    Write-Host "$white   {0,-30} {1,12}$reset" -f "Nome", "Memoria (MB)"
    Write-Host "   " + ("-" * 45)
    Get-Process | Sort-Object WS -Descending | Select-Object -First 10 | ForEach-Object {
        $memMB = [math]::Round($_.WS / 1MB, 1)
        $cor   = if ($memMB -gt 500) { [char]27 + "[91m" } elseif ($memMB -gt 200) { [char]27 + "[93m" } else { [char]27 + "[37m" }
        Write-Host "$cor   {0,-30} {1,12}$reset" -f $_.Name, $memMB
    }

    Write-Host ""
    if ($cpu -gt 80)        { Write-Aviso "CPU muito alta! Veja os processos acima." }
    if ($memUsadaPct -gt 85){ Write-Aviso "Memoria muito alta! Considere fechar programas." }
    Write-Log "CPU: $cpu pct | Memoria: $memUsadaPct pct ($memUsadaGB GB / $memTotalGB GB)"
    Write-Pausar
}

# ===========================================================================
# 6 - SFC / DISM
# ===========================================================================
function Invoke-VerificarSistema {
    Write-SectionTitle "VERIFICACAO DE ARQUIVOS DO SISTEMA" "Yellow"
    Write-Aviso "Esta etapa pode demorar 10 a 30 minutos. Nao feche a janela."
    $Global:Acoes.Add("SFC/DISM executado em $(Get-Date -Format 'HH:mm')")
    Write-Host ""

    Write-Step 1 2 "SFC - Verificando integridade dos arquivos do Windows"
    sfc /scannow 2>&1 | Tee-Object -FilePath $Global:LogFile -Append
    Write-Resultado "SFC concluido"

    Write-Step 2 2 "DISM - Reparando a imagem do Windows"
    DISM /Online /Cleanup-Image /RestoreHealth 2>&1 | Tee-Object -FilePath $Global:LogFile -Append
    Write-Resultado "DISM concluido"

    Write-Pausar
}

# ===========================================================================
# 7 - CHKDSK
# ===========================================================================
function Invoke-VerificarDisco {
    Write-SectionTitle "VERIFICACAO DE DISCO (CHKDSK)" "Yellow"
    $Global:Acoes.Add("CHKDSK executado em $(Get-Date -Format 'HH:mm')")

    $white = [char]27 + "[97m"; $reset = [char]27 + "[0m"
    Write-Host ""
    Write-Host "$white   Discos disponiveis:$reset"
    Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match "^[A-Z]:\\" } | ForEach-Object {
        $livreGB = [math]::Round($_.Free / 1GB, 1)
        $usadoGB = [math]::Round(($_.Used) / 1GB, 1)
        $totalGB = [math]::Round(($_.Free + $_.Used) / 1GB, 1)
        $pct     = if ($totalGB -gt 0) { [math]::Round(($_.Used / ($_.Free + $_.Used)) * 100) } else { 0 }
        $cor     = if ($pct -gt 90) { "Red" } elseif ($pct -gt 70) { "Yellow" } else { "Green" }
        Write-ProgressBar "   $($_.Name): ($usadoGB GB usados de $totalGB GB):" $pct $cor
    }

    Write-Host ""
    Write-Host -NoNewline "$white   Letra do disco para verificar (ex: C): $reset"
    $letra = Read-Host
    if ($letra -notmatch "^[A-Z]$") { Write-Resultado "Letra invalida." "ERRO"; Write-Pausar; return }

    Write-Step 1 1 "Verificando disco $letra`:"
    chkdsk "$letra`:" /scan 2>&1 | Tee-Object -FilePath $Global:LogFile -Append

    Write-Host ""
    Write-Host -NoNewline "$white   Agendar reparo completo no proximo reinicio? (S/N): $reset"
    $resp = Read-Host
    if ($resp -match "^[Ss]$") {
        "Y" | chkdsk "$letra`:" /f /r
        Write-Aviso "Reparo agendado. Reinicie para executar o CHKDSK."
    }

    Write-Pausar
}

# ===========================================================================
# 8 - OTIMIZAR DESEMPENHO
# ===========================================================================
function Invoke-OtimizarDesempenho {
    Write-SectionTitle "OTIMIZACAO DE DESEMPENHO" "Blue"
    $Global:Acoes.Add("Otimizacao de desempenho em $(Get-Date -Format 'HH:mm')")

    Write-Step 1 3 "Ativando plano de energia Alto Desempenho"
    powercfg -setactive 8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c 2>&1 | Out-Null
    Write-Resultado "Plano de energia ajustado"

    Write-Step 2 3 "Programas na inicializacao do Windows"
    $white = [char]27 + "[97m"; $gray = [char]27 + "[37m"; $reset = [char]27 + "[0m"
    Write-Host ""
    Write-Host "$white   {0,-40} {1,-20}$reset" -f "Programa", "Fabricante"
    Write-Host "   " + ("-" * 62)
    Get-CimInstance Win32_StartupCommand | Select-Object -First 15 | ForEach-Object {
        Write-Host "$gray   {0,-40} {1,-20}$reset" -f ($_.Name -replace ".{0,40}","$&"), $_.User
    }
    Write-Aviso "Para desabilitar itens: Ctrl+Shift+Esc -> Inicializar"

    Write-Step 3 3 "Otimizando unidades de disco"
    defrag $env:SystemDrive /O /U 2>&1 | Out-File $Global:LogFile -Append
    Write-Resultado "Otimizacao de disco concluida"

    Write-Pausar
}

# ===========================================================================
# 9 - PONTO DE RESTAURACAO
# ===========================================================================
function Invoke-CriarRestauracao {
    Write-SectionTitle "PONTO DE RESTAURACAO DO SISTEMA" "Blue"
    $Global:Acoes.Add("Ponto de restauracao criado em $(Get-Date -Format 'HH:mm')")

    Write-Step 1 2 "Habilitando protecao do sistema"
    Enable-ComputerRestore -Drive "$env:SystemDrive\" -ErrorAction SilentlyContinue
    Write-Resultado "Protecao do sistema verificada"

    Write-Step 2 2 "Criando ponto de restauracao"
    try {
        Checkpoint-Computer -Description "Manutencao PC - $(Get-Date -Format 'dd/MM/yyyy HH:mm')" `
                            -RestorePointType "MODIFY_SETTINGS" -ErrorAction Stop
        Write-Resultado "Ponto de restauracao criado com sucesso!"
    } catch {
        Write-Resultado "Nao foi possivel criar o ponto (Windows limita a 1 por 24h ou protecao desabilitada)" "AVISO"
    }

    Write-Pausar
}

# ===========================================================================
# 10 - WINDOWS UPDATE
# ===========================================================================
function Invoke-VerificarUpdate {
    Write-SectionTitle "VERIFICACAO DO WINDOWS UPDATE" "Blue"
    $Global:Acoes.Add("Verificacao de Windows Update em $(Get-Date -Format 'HH:mm')")

    Write-Step 1 2 "Verificando servico Windows Update"
    $svc = Get-Service -Name wuauserv
    if ($svc.Status -eq "Running") {
        Write-Resultado "Servico Windows Update: RODANDO"
    } else {
        Write-Resultado "Servico Windows Update: $($svc.Status) - tentando iniciar..." "AVISO"
        Start-Service -Name wuauserv -ErrorAction SilentlyContinue
    }

    Write-Step 2 2 "Abrindo Windows Update para verificacao"
    Start-Process "ms-settings:windowsupdate"
    Write-Resultado "Windows Update aberto. Verifique atualizacoes pendentes na janela aberta."

    Write-Pausar
}

# ===========================================================================
# 11 - WINDOWS DEFENDER SCAN
# ===========================================================================
function Invoke-DefenderScan {
    Write-SectionTitle "VERIFICACAO RAPIDA - WINDOWS DEFENDER" "Red"
    Write-Aviso "O scan rapido pode levar alguns minutos. Aguarde..."
    $Global:Acoes.Add("Scan do Defender em $(Get-Date -Format 'HH:mm')")
    Write-Host ""

    Write-Step 1 1 "Iniciando scan rapido do Windows Defender"
    try {
        Start-MpScan -ScanType QuickScan -ErrorAction Stop
        Write-Resultado "Scan concluido sem ameacas detectadas!"
        $status = Get-MpComputerStatus
        Write-Resultado "Definicoes do Defender: $($status.AntivirusSignatureLastUpdated.ToString('dd/MM/yyyy'))"
    } catch {
        Write-Resultado "Nao foi possivel executar o scan via PowerShell." "AVISO"
        Write-Aviso "Abrindo Windows Security para scan manual..."
        Start-Process "windowsdefender:"
    }

    Write-Pausar
}

# ===========================================================================
# 12 - EXECUTAR TUDO
# ===========================================================================
function Invoke-ExecutarTudo {
    Write-SectionTitle "EXECUTANDO TODAS AS ROTINAS" "Green"
    $white = [char]27 + "[97m"; $reset = [char]27 + "[0m"
    Write-Host "$white   Ordem de execucao:$reset"
    Write-Host "   1. Ponto de restauracao  -> 2. Reparo de rede -> 3. Limpeza temp"
    Write-Host "   4. Cache navegadores     -> 5. Diagnostico    -> 6. SFC/DISM"
    Write-Host "   7. CHKDSK                -> 8. Desempenho     -> 9. Relatorio final"
    Write-Host ""
    Write-Host -NoNewline "$white   Confirmar execucao completa? (S/N): $reset"
    $resp = Read-Host
    if ($resp -notmatch "^[Ss]$") { return }

    Invoke-CriarRestauracao
    Invoke-RepararRede
    Invoke-LimpezaTemp
    Invoke-LimpezaNavegadores
    Invoke-Diagnostico
    Invoke-OtimizarDesempenho
    Invoke-GerarRelatorio
}

# ===========================================================================
# 13 - INFORMACOES DO SISTEMA
# ===========================================================================
function Invoke-InfoSistema {
    Write-SectionTitle "INFORMACOES DO SISTEMA" "Cyan"

    $white = [char]27 + "[97m"; $gray = [char]27 + "[37m"; $cyan = [char]27 + "[96m"; $reset = [char]27 + "[0m"
    $os    = Get-CimInstance Win32_OperatingSystem
    $cpu   = Get-CimInstance Win32_Processor | Select-Object -First 1
    $bios  = Get-CimInstance Win32_BIOS
    $sys   = Get-CimInstance Win32_ComputerSystem
    $memGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    $upMin = [math]::Round((Get-Date).Subtract($os.LastBootUpTime).TotalMinutes)
    $upH   = [math]::Round($upMin / 60, 1)

    $info = @(
        @{ Label = "Sistema Operacional";  Valor = $os.Caption },
        @{ Label = "Versao do Windows";    Valor = $os.Version },
        @{ Label = "Arquitetura";          Valor = $os.OSArchitecture },
        @{ Label = "Fabricante do PC";     Valor = $sys.Manufacturer },
        @{ Label = "Modelo";               Valor = $sys.Model },
        @{ Label = "Processador";          Valor = $cpu.Name },
        @{ Label = "Nucleos";              Valor = "$($cpu.NumberOfCores) fisicos / $($cpu.NumberOfLogicalProcessors) logicos" },
        @{ Label = "Memoria RAM Total";    Valor = "$memGB GB" },
        @{ Label = "Versao do BIOS";       Valor = $bios.SMBIOSBIOSVersion },
        @{ Label = "Ligado ha";            Valor = "$upH horas ($upMin min)" }
    )

    Write-Host "$white   {0,-25} {1}$reset" -f "Propriedade", "Valor"
    Write-Host "   " + ("-" * 70)
    foreach ($item in $info) {
        Write-Host "   $cyan{0,-25}$reset $gray{1}$reset" -f $item.Label, $item.Valor
    }

    Write-Host ""
    Write-Host "$white   Discos:$reset"
    Write-Host "   " + ("-" * 70)
    Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match "^[A-Z]:\\" } | ForEach-Object {
        if (($_.Used + $_.Free) -gt 0) {
            $livreGB  = [math]::Round($_.Free / 1GB, 1)
            $totalGB  = [math]::Round(($_.Used + $_.Free) / 1GB, 1)
            $pct      = [math]::Round($_.Used / ($_.Used + $_.Free) * 100)
            $cor      = if ($pct -gt 90) { "Red" } elseif ($pct -gt 70) { "Yellow" } else { "Green" }
            Write-ProgressBar "   $($_.Name): ($livreGB GB livres de $totalGB GB)" $pct $cor
        }
    }

    Write-Pausar
}

# ===========================================================================
# 14 - GERAR RELATORIO
# ===========================================================================
function Invoke-GerarRelatorio {
    Write-SectionTitle "GERANDO RELATORIO FINAL" "Green"
    $Global:Acoes.Add("Relatorio gerado em $(Get-Date -Format 'HH:mm')")

    $os    = Get-CimInstance Win32_OperatingSystem
    $cpu   = Get-CimInstance Win32_Processor | Select-Object -First 1
    $sys   = Get-CimInstance Win32_ComputerSystem
    $memGB = [math]::Round($os.TotalVisibleMemorySize / 1MB, 1)
    $cpuUso = (Get-CimInstance Win32_Processor | Measure-Object -Property LoadPercentage -Average).Average
    $memUsadaPct = [math]::Round((($os.TotalVisibleMemorySize - $os.FreePhysicalMemory) / $os.TotalVisibleMemorySize) * 100, 1)

    # TXT
    $txt = @"
==========================================================================
  RELATORIO DE MANUTENCAO DE PC
==========================================================================
  Data/Hora   : $(Get-Date -Format 'dd/MM/yyyy HH:mm:ss')
  Computador  : $env:COMPUTERNAME
  Usuario     : $env:USERNAME
  Log tecnico : $Global:LogFile

--------------------------------------------------------------------------
  SISTEMA
--------------------------------------------------------------------------
  OS          : $($os.Caption) $($os.OSArchitecture)
  Versao      : $($os.Version)
  Fabricante  : $($sys.Manufacturer) $($sys.Model)
  CPU         : $($cpu.Name)
  RAM Total   : $memGB GB

--------------------------------------------------------------------------
  STATUS ATUAL
--------------------------------------------------------------------------
  Uso de CPU  : $cpuUso%
  Uso de RAM  : $memUsadaPct%

--------------------------------------------------------------------------
  DISCOS
--------------------------------------------------------------------------
"@
    Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match "^[A-Z]:\\" } | ForEach-Object {
        if (($_.Used + $_.Free) -gt 0) {
            $livre = [math]::Round($_.Free / 1GB, 1)
            $total = [math]::Round(($_.Used + $_.Free) / 1GB, 1)
            $pct   = [math]::Round($_.Used / ($_.Used + $_.Free) * 100)
            $txt  += "  Disco $($_.Name): $livre GB livres de $total GB ($pct pct usado)`n"
        }
    }

    $txt += "`n--------------------------------------------------------------------------`n"
    $txt += "  ACOES REALIZADAS NESTA SESSAO`n"
    $txt += "--------------------------------------------------------------------------`n"
    foreach ($a in $Global:Acoes) { $txt += "  * $a`n" }
    $txt += "`n==========================================================================`n"

    $txt | Out-File -FilePath $Global:ReportFile -Encoding UTF8

    # HTML
    $diskRows = ""
    Get-PSDrive -PSProvider FileSystem | Where-Object { $_.Root -match "^[A-Z]:\\" } | ForEach-Object {
        if (($_.Used + $_.Free) -gt 0) {
            $livre = [math]::Round($_.Free / 1GB, 1)
            $total = [math]::Round(($_.Used + $_.Free) / 1GB, 1)
            $pct   = [math]::Round($_.Used / ($_.Used + $_.Free) * 100)
            $cor   = if ($pct -gt 90) { "#f85149" } elseif ($pct -gt 70) { "#e3b341" } else { "#3fb950" }
            $diskRows += "<tr><td>$($_.Name):</td><td>$livre GB livres de $total GB</td><td><div style='background:#21262d;border-radius:4px;height:10px;width:200px'><div style='background:$cor;width:$($pct)%;height:10px;border-radius:4px'></div></div></td><td>$($pct)%</td></tr>"
        }
    }
    $acoesRows = ($Global:Acoes | ForEach-Object { "<li>$_</li>" }) -join "`n"
    $cpuCor = if ($cpuUso -gt 80) { "#f85149" } elseif ($cpuUso -gt 50) { "#e3b341" } else { "#3fb950" }
    $memCor = if ($memUsadaPct -gt 85) { "#f85149" } elseif ($memUsadaPct -gt 65) { "#e3b341" } else { "#3fb950" }

    $html = @"
<!DOCTYPE html>
<html lang='pt-BR'>
<head>
<meta charset='UTF-8'>
<title>Relatorio de Manutencao - $env:COMPUTERNAME</title>
<style>
  body { font-family: 'Segoe UI', sans-serif; background: #0d1117; color: #e6edf3; margin: 0; padding: 32px; }
  h1 { color: #39d5ff; font-size: 22px; border-bottom: 1px solid #30363d; padding-bottom: 12px; }
  h2 { color: #3fb950; font-size: 15px; margin-top: 28px; }
  .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 16px; margin: 16px 0; }
  .card { background: #161b22; border: 1px solid #30363d; border-radius: 8px; padding: 16px; }
  .label { color: #8b949e; font-size: 12px; margin-bottom: 4px; }
  .value { color: #e6edf3; font-size: 14px; font-weight: 600; }
  .gauge { background: #21262d; border-radius: 4px; height: 8px; margin-top: 8px; }
  .fill { height: 8px; border-radius: 4px; }
  table { width: 100%; border-collapse: collapse; margin-top: 12px; }
  td, th { padding: 8px 12px; text-align: left; border-bottom: 1px solid #21262d; font-size: 13px; }
  th { color: #8b949e; font-weight: 500; }
  ul { color: #8b949e; padding-left: 20px; line-height: 2; }
  .badge { display: inline-block; background: #0d2744; color: #58a6ff; padding: 2px 10px; border-radius: 4px; font-size: 12px; }
  footer { margin-top: 40px; color: #484f58; font-size: 12px; }
</style>
</head>
<body>
<h1>Relatorio de Manutencao de PC</h1>
<div class='grid'>
  <div class='card'>
    <div class='label'>Computador</div>
    <div class='value'>$env:COMPUTERNAME <span class='badge'>$($sys.Manufacturer)</span></div>
    <div class='label' style='margin-top:12px'>Sistema Operacional</div>
    <div class='value'>$($os.Caption)</div>
  </div>
  <div class='card'>
    <div class='label'>Data / Hora do Relatorio</div>
    <div class='value'>$(Get-Date -Format 'dd/MM/yyyy HH:mm')</div>
    <div class='label' style='margin-top:12px'>Usuario</div>
    <div class='value'>$env:USERNAME</div>
  </div>
  <div class='card'>
    <div class='label'>Uso de CPU</div>
    <div class='value' style='color:$cpuCor'>$cpuUso%</div>
    <div class='gauge'><div class='fill' style='width:$cpuUso%;background:$cpuCor'></div></div>
  </div>
  <div class='card'>
    <div class='label'>Uso de Memoria RAM</div>
    <div class='value' style='color:$memCor'>$memUsadaPct% de $memGB GB</div>
    <div class='gauge'><div class='fill' style='width:$memUsadaPct%;background:$memCor'></div></div>
  </div>
</div>
<h2>Discos</h2>
<table><tr><th>Drive</th><th>Espaco</th><th>Uso</th><th>%</th></tr>$diskRows</table>
<h2>Acoes Realizadas Nesta Sessao</h2>
<ul>$acoesRows</ul>
<footer>Relatorio gerado automaticamente por Manutencao-PC.ps1 | Log tecnico: $Global:LogFile</footer>
</body>
</html>
"@
    $html | Out-File -FilePath $Global:HtmlReport -Encoding UTF8

    Write-Resultado "Relatorio TXT salvo: $Global:ReportFile"
    Write-Resultado "Relatorio HTML salvo: $Global:HtmlReport"
    Start-Process $Global:HtmlReport

    Write-Pausar
}

# ===========================================================================
# 15 - GESTAO DE USUARIOS (PLACEHOLDER)
# ===========================================================================
function Invoke-GestaoUsuarios {
    Write-SectionTitle "GESTAO DE USUARIOS - ACTIVE DIRECTORY" "Magenta"

    $yellow = [char]27 + "[93m"; $gray = [char]27 + "[37m"; $dim = [char]27 + "[90m"; $reset = [char]27 + "[0m"
    Write-Host "$yellow"
    Write-Host "   +==========================================================+"
    Write-Host "   |         MODULO EM DESENVOLVIMENTO                       |"
    Write-Host "   +==========================================================+"
    Write-Host "$reset"
    Write-Host "$gray   Este modulo sera implementado em breve e incluira:$reset"
    Write-Host ""
    Write-Host "$dim   [  ]$reset $gray Criar usuario no Active Directory"
    Write-Host "$dim   [  ]$reset $gray Desativar / remover usuario (offboarding)"
    Write-Host "$dim   [  ]$reset $gray Resetar senha"
    Write-Host "$dim   [  ]$reset $gray Listar usuarios e grupos"
    Write-Host "$dim   [  ]$reset $gray Relatorio de usuarios inativos"
    Write-Host "$dim   [  ]$reset $gray Auditoria de permissoes"
    Write-Host ""
    Write-Host "$yellow   Requisitos: modulo RSAT (Remote Server Administration Tools)$reset"
    Write-Host "$yellow   e acesso a um Domain Controller na rede.$reset"
    Write-Host ""

    Write-Pausar
}

# ===========================================================================
# LOOP PRINCIPAL
# ===========================================================================
Write-Log "=== Sessao iniciada | PC: $env:COMPUTERNAME | Usuario: $env:USERNAME ==="

while ($true) {
    Show-Menu
    $opcao = Read-Host

    switch ($opcao.Trim()) {
        "1"  { Invoke-RepararRede }
        "2"  { Invoke-TesteVelocidade }
        "3"  { Invoke-LimpezaTemp }
        "4"  { Invoke-LimpezaNavegadores }
        "5"  { Invoke-Diagnostico }
        "6"  { Invoke-VerificarSistema }
        "7"  { Invoke-VerificarDisco }
        "8"  { Invoke-OtimizarDesempenho }
        "9"  { Invoke-CriarRestauracao }
        "10" { Invoke-VerificarUpdate }
        "11" { Invoke-DefenderScan }
        "12" { Invoke-ExecutarTudo }
        "13" { Invoke-InfoSistema }
        "14" { Invoke-GerarRelatorio }
        "15" { Invoke-GestaoUsuarios }
        "0"  {
            Write-Log "=== Sessao encerrada ==="
            $cyan = [char]27 + "[96m"; $reset = [char]27 + "[0m"
            Clear-Host
            Write-Host ""
            Write-Host "$cyan   Sessao encerrada. Log salvo em:$reset"
            Write-Host "   $Global:LogFile"
            Write-Host ""
            Start-Sleep 2
            exit
        }
        default {
            $red = [char]27 + "[91m"; $reset = [char]27 + "[0m"
            Write-Host "$red   Opcao invalida. Tente novamente.$reset"
            Start-Sleep 1
        }
    }
}
